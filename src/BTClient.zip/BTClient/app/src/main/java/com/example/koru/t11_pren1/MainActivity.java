package com.example.koru.t11_pren1;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity{
    private TextView txtRecMsg;
    private TextView txtStatus;
    private Button cmdStart;

    private BluetoothAdapter btAdapter;
    private BluetoothDevice device;

    private BluetoothSocket btSocket;
    private AsyncTask<BluetoothSocket, Void, String> readerTask;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtRecMsg = (TextView)findViewById(R.id.txtRecMessage);
        txtStatus = (TextView)findViewById(R.id.txtStatus);
        cmdStart = (Button)findViewById(R.id.cmdStartProcess);

        btAdapter = BluetoothAdapter.getDefaultAdapter();

        Log.d("Bluetoothadapter", btAdapter.getName());
        for (BluetoothDevice btDev : btAdapter.getBondedDevices()) {
            Log.d("BluetoothDevices", btDev.getName());
            device = btDev;
            break;
        }

        try {
            btSocket = device.createRfcommSocketToServiceRecord(UUID.fromString("b9263ab4-2eb9-4792-9472-b20b97f4b2e9"));
            btAdapter.cancelDiscovery();
            btSocket.connect();

            if (btSocket.isConnected()) {
                Log.d("ReaderTask", "Starting reader...");
                readerTask = new BluetoothReader().execute(btSocket);
            }

            txtStatus.setText("Status: Connected to robot");
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

    @Override
    protected void onDestroy() {
        readerTask.cancel(true);

        try {
            String message = "disconnect";
            OutputStream oStream = btSocket.getOutputStream();
            byte[] msgBuffer = message.getBytes();
            oStream.write(msgBuffer);
            oStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

        super.onDestroy();
    }

    public void startProcess(View o) {
        if (!btSocket.isConnected()) { return; }

        String message = "start-process";

        try {
            OutputStream oStream = btSocket.getOutputStream();
            byte[] msgBuffer = message.getBytes();
            oStream.write(msgBuffer);
            oStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class BluetoothReader extends AsyncTask<BluetoothSocket, Void, String>  {
        @Override
        protected String doInBackground(BluetoothSocket... params) {
            BluetoothSocket btSocket = params[0];
            InputStream iStream;
            int iMsg;
            String sMsg = "";

            try {
                Log.d("BluetoothReader", "Is connected:" + btSocket.isConnected());
                while (btSocket.isConnected()) {
                    iStream = btSocket.getInputStream();

                    while((iMsg = iStream.read())!=-1) {
                        // converts integer to character
                        char charMsg = (char)iMsg;

                        if (charMsg != '#') {
                            sMsg += charMsg;
                        } else {
                            return sMsg;
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return "";
        }

        @Override
        protected void onPostExecute(String s) {
            Log.d("BluetoothReader", "Received message from server: " + s);
            txtRecMsg.setText("Received message from server: " + s);

            if (s.contains("status") && s.contains("started")) {
                cmdStart.setEnabled(false);
            }

            readerTask = new BluetoothReader().execute(btSocket);
        }
    }
}
